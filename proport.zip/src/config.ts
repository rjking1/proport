//copiedfrom pybase_plus -- need to move to a common location
// along with Common.js

// do not commit this as there is sensitive info in this file

export const POST_PHP = "https://www.artspace7.com.au/dsql/json_helper_post.php";
export const GET_PHP = "https://www.artspace7.com.au/dsql/json_helper_get.php";

export const BUREST_PHP = `https://www.artspace7.com.au/dsql/burest.php`;
export const EMAILER_PHP = `https://thehutgallery.com.au/dsql/emailer3.php`;

export const MEMBERSHIP_EMAIL = "Heather King <membership@thehutgallery.com.au>";
export const INFO_EMAIL = "Shirley Dougan <info@thehutgallery.com.au>";
export const BCC_EMAIL = "heather@artspace7.com.au";
