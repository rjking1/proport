<script>
  import { TableHead, TableHeadCell } from "flowbite-svelte";
</script>

<TableHead>
  <TableHeadCell>
    <span class="sr-only"> Open </span>
  </TableHeadCell>
  <TableHeadCell>Project</TableHeadCell>
  <TableHeadCell>Portfolio</TableHeadCell>
  <TableHeadCell>Interest</TableHeadCell>
  <TableHeadCell>Progress</TableHeadCell>
</TableHead>
