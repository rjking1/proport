<script>
  import RideHeader from "./RideHeader.svelte";
  import Ride from "./Ride.svelte";
  import { Table } from "flowbite-svelte";

  export let rides;
  export let onEdit;

  function handleEdit(ride) {
    onEdit(ride);
  }
</script>

<Table striped={true}>
  <RideHeader />
  {#each rides as ride}
    <Ride bind:ride onEdit={() => handleEdit(ride)} />
  {/each}
</Table>
