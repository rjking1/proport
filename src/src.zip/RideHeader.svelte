<script>
  import { TableHead, TableHeadCell } from "flowbite-svelte";
</script>

<TableHead>
  <TableHeadCell>Date</TableHeadCell>
  <TableHeadCell>Km</TableHeadCell>
  <TableHeadCell>Alt gain</TableHeadCell>
  <TableHeadCell>Description</TableHeadCell>
  <TableHeadCell>Weather</TableHeadCell>
  <TableHeadCell>
    <span class="sr-only"> Edit </span>
  </TableHeadCell>
</TableHead>
