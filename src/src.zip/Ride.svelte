<script>
  import { TableBodyRow, TableBodyCell } from "flowbite-svelte";

  export let ride;
  export let onEdit;

  function handleEdit() {
    onEdit(ride);
  }
</script>

<TableBodyRow>
  <TableBodyCell>{ride.ride_date}</TableBodyCell>
  <TableBodyCell>{ride.km}</TableBodyCell>
  <TableBodyCell>{ride.alt_gain}</TableBodyCell>
  <TableBodyCell>{ride.description}</TableBodyCell>
  <TableBodyCell>{ride.weather}</TableBodyCell>
  <TableBodyCell>
    <button on:click={handleEdit}>✎ Edit</button>
  </TableBodyCell>
</TableBodyRow>
