import LoginPage from "./LoginPage.svelte";
import ListPage from "./ListPage.svelte";
import NotFound from "./NotFound.svelte";
import AddPage from "./AddPage.svelte";
import QueryPage from "./QueryPage.svelte";
import { wrap } from "svelte-spa-router/wrap";

export const routes = {
  // "/": Home,
  "/": LoginPage,
  // Exact path + parameter
  // "/article/:title": Article,
  // "/login": LoginPage,
  "/list": ListPage,
  "/add": AddPage,
  "/query": QueryPage,
  // Wildcard
  "*": NotFound,
};
